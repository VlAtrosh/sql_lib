﻿using System;
using System.Collections.Generic;

class Program
{
    private static BookStoreService _bookStoreService;

    static void Main(string[] args)
    {
        // Инициализация слоев
        var db = new BookStoreDatabase("localhost", "Library", "postgres", "");
        _bookStoreService = new BookStoreService(db);

        try
        {
            if (!db.TestConnection())
            {
                Console.WriteLine("Не удалось подключиться к базе данных");
                return;
            }

            bool exitRequested = false;
            while (!exitRequested)
            {
                Console.Clear();
                Console.WriteLine("=== Система управления книжным магазином ===");
                Console.WriteLine("1. Показать все книги с авторами");
                Console.WriteLine("2. Добавить книгу");
                Console.WriteLine("3. Добавить автора");
                Console.WriteLine("4. Найти книгу по автору");
                Console.WriteLine("5. Обновить информацию о книге");
                Console.WriteLine("6. Удалить книгу");
                Console.WriteLine("7. Показать всех авторов");
                Console.WriteLine("8. Удалить автора");
                Console.WriteLine("9. Показать книги без авторов");
                Console.WriteLine("10. Выход");
                Console.Write("Выберите действие: ");

                var input = Console.ReadLine();
                Console.Clear();

                try
                {
                    switch (input)
                    {
                        case "1":
                            PrintBooksTableWithAuthors(_bookStoreService.GetAllBooksWithAuthors());
                            break;
                        case "2":
                            AddNewBook();
                            break;
                        case "3":
                            AddNewAuthor();
                            break;
                        case "4":
                            SearchBooksByAuthor();
                            break;
                        case "5":
                            UpdateBookInfo();
                            break;
                        case "6":
                            DeleteBook();
                            break;
                        case "7":
                            ShowAllAuthors();
                            break;
                        case "8":
                            DeleteAuthor();
                            break;
                        case "9":
                            ShowBooksWithoutAuthors();
                            break;
                        case "10":
                            exitRequested = true;
                            continue;
                        default:
                            throw new InvalidOperationException("Некорректный пункт меню. Введите число от 1 до 10.");
                    }
                }
                catch (Exception ex)
                {
                    ShowError(ex.Message);
                }

                Console.WriteLine("\nНажмите любую клавишу для продолжения...");
                Console.ReadKey();
            }
        }
        catch (Exception ex)
        {
            ShowError($"Критическая ошибка: {ex.Message}", true);
        }
    }

    #region Вспомогательные методы для отображения данных

    private static void ShowError(string message, bool isCritical = false)
    {
        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine(message);
        Console.ResetColor();
        if (isCritical)
        {
            Console.WriteLine("\nНажмите любую клавишу для выхода...");
            Console.ReadKey();
        }
    }

    private static void ShowBooksWithoutAuthors()
    {
        try
        {
            var books = _bookStoreService.GetBooksWithoutAuthors();
            Console.WriteLine("=== Книги без авторов ===");
            PrintBooksTable(books);

            Console.Write("\nХотите добавить автора к книге? (y/n): ");
            if (Console.ReadLine()?.ToLower() == "y")
            {
                Console.Write("Введите ID книги: ");
                if (int.TryParse(Console.ReadLine(), out var bookId))
                {
                    Console.WriteLine("Доступные авторы:");
                    ShowAllAuthors();

                    Console.Write("Введите ID автора: ");
                    if (int.TryParse(Console.ReadLine(), out var authorId))
                    {
                        _bookStoreService.AddAuthorToBook(bookId, authorId);
                        Console.WriteLine("Автор успешно добавлен к книге!");
                    }
                }
            }
        }
        catch (Exception ex)
        {
            throw new Exception("Ошибка при работе с книгами без авторов", ex);
        }
    }

    private static void DeleteAuthor()
    {
        try
        {
            Console.WriteLine("=== Удаление автора ===");
            ShowAllAuthors();

            Console.Write("\nВведите ID автора для удаления: ");
            if (!int.TryParse(Console.ReadLine(), out var authorId))
            {
                throw new ArgumentException("Некорректный ID автора.");
            }

            _bookStoreService.DeleteAuthor(authorId);
            Console.WriteLine("\nАвтор успешно удален.");
            ShowAllAuthors();
        }
        catch (Exception ex)
        {
            throw new Exception("Ошибка при удалении автора", ex);
        }
    }

    private static void ShowAllAuthors()
    {
        try
        {
            var authors = _bookStoreService.GetAllAuthors();
            Console.WriteLine("Список авторов:");
            Console.WriteLine(new string('-', 50));
            Console.WriteLine("| {0,-5} | {1,-20} | {2,-20} |", "ID", "Имя", "Фамилия");
            Console.WriteLine(new string('-', 50));

            foreach (var author in authors)
            {
                Console.WriteLine("| {0,-5} | {1,-20} | {2,-20} |",
                                author.AuthorId,
                                author.FirstName,
                                author.LastName);
            }
            Console.WriteLine(new string('-', 50));
        }
        catch (Exception ex)
        {
            throw new Exception("Ошибка при получении списка авторов", ex);
        }
    }

    private static void AddNewAuthor()
    {
        try
        {
            Console.WriteLine("=== Добавление нового автора ===");

            Console.Write("Имя: ");
            var firstName = Console.ReadLine();

            Console.Write("Фамилия: ");
            var lastName = Console.ReadLine();

            Console.Write("Биография (необязательно): ");
            var bio = Console.ReadLine();

            var author = _bookStoreService.AddAuthor(firstName, lastName, bio);
            Console.WriteLine($"\nАвтор успешно добавлен с ID: {author.AuthorId}");
        }
        catch (Exception ex)
        {
            throw new Exception("Ошибка при добавлении автора", ex);
        }
    }

    private static void AddNewBook()
    {
        try
        {
            Console.WriteLine("=== Добавление новой книги ===");

            Console.WriteLine("\nСписок доступных авторов:");
            ShowAllAuthors();

            Console.Write("\nНазвание: ");
            var title = Console.ReadLine();

            Console.Write("ISBN: ");
            var isbn = Console.ReadLine();

            Console.Write("Цена: ");
            decimal.TryParse(Console.ReadLine(), out var price);

            Console.Write("Издательство (необязательно): ");
            var publisher = Console.ReadLine();

            Console.Write("Дата публикации (ГГГГ-ММ-ДД, необязательно): ");
            DateTime? pubDate = null;
            var dateInput = Console.ReadLine();
            if (!string.IsNullOrWhiteSpace(dateInput))
            {
                DateTime.TryParse(dateInput, out var tempDate);
                pubDate = tempDate;
            }

            Console.Write("ID автора: ");
            int.TryParse(Console.ReadLine(), out var authorId);

            var book = _bookStoreService.AddBook(title, isbn, price, publisher, pubDate, authorId);
            Console.WriteLine($"\nКнига успешно добавлена с ID: {book.BookId}");
        }
        catch (Exception ex)
        {
            throw new Exception("Ошибка при добавлении книги", ex);
        }
    }

    private static void SearchBooksByAuthor()
    {
        try
        {
            Console.WriteLine("=== Поиск книг по автору ===");
            ShowAllAuthors();

            Console.Write("\nВведите ID автора: ");
            if (!int.TryParse(Console.ReadLine(), out var authorId))
                throw new ArgumentException("Некорректный ID автора.");

            var books = _bookStoreService.GetBooksByAuthor(authorId);
            Console.WriteLine($"\nКниги автора:");
            PrintBooksTable(books);
        }
        catch (Exception ex)
        {
            throw new Exception("Ошибка при поиске книг", ex);
        }
    }

    private static void UpdateBookInfo()
    {
        try
        {
            Console.WriteLine("=== Обновление информации о книге ===");
            PrintBooksTableWithAuthors(_bookStoreService.GetAllBooksWithAuthors());

            Console.Write("\nВведите ID книги для обновления: ");
            if (!int.TryParse(Console.ReadLine(), out var bookId))
                throw new ArgumentException("Некорректный ID книги.");

            Console.Write("Новое название: ");
            var title = Console.ReadLine();

            Console.Write("Новая цена: ");
            decimal.TryParse(Console.ReadLine(), out var price);

            var updatedBook = _bookStoreService.UpdateBook(bookId, title, price);
            Console.WriteLine("\nИнформация о книге успешно обновлена.");
            PrintBooksTableWithAuthors(_bookStoreService.GetAllBooksWithAuthors());
        }
        catch (Exception ex)
        {
            throw new Exception("Ошибка при обновлении книги", ex);
        }
    }

    private static void DeleteBook()
    {
        try
        {
            Console.WriteLine("=== Удаление книги ===");
            PrintBooksTableWithAuthors(_bookStoreService.GetAllBooksWithAuthors());

            Console.Write("\nВведите ID книги для удаления: ");
            if (!int.TryParse(Console.ReadLine(), out var bookId))
                throw new ArgumentException("Некорректный ID книги.");

            _bookStoreService.DeleteBook(bookId);
            Console.WriteLine("\nКнига успешно удалена.");
            PrintBooksTableWithAuthors(_bookStoreService.GetAllBooksWithAuthors());
        }
        catch (Exception ex)
        {
            throw new Exception("Ошибка при удалении книги", ex);
        }
    }

    private static void PrintBooksTableWithAuthors(List<BookWithAuthor> books)
    {
        Console.WriteLine("\nСписок книг в магазине (с авторами):");
        Console.WriteLine(new string('-', 110));
        Console.WriteLine("| {0,-5} | {1,-25} | {2,-15} | {3,-10} | {4,-15} | {5,-20} |",
                         "ID", "Название", "ISBN", "Цена", "Издательство", "Автор");
        Console.WriteLine(new string('-', 110));

        foreach (var book in books)
        {
            Console.WriteLine("| {0,-5} | {1,-25} | {2,-15} | {3,-10:C2} | {4,-15} | {5,-20} |",
                            book.BookId,
                            Truncate(book.Title, 25),
                            book.ISBN,
                            book.Price,
                            Truncate(book.Publisher ?? "-", 15),
                            book.AuthorId == 0 ? "Нет автора" : $"{book.AuthorFirstName} {book.AuthorLastName}");
        }
        Console.WriteLine(new string('-', 110));
    }

    private static void PrintBooksTable(List<Book> books)
    {
        Console.WriteLine("\nСписок книг:");
        Console.WriteLine(new string('-', 80));
        Console.WriteLine("| {0,-5} | {1,-30} | {2,-15} | {3,-10} | {4,-15} |",
                         "ID", "Название", "ISBN", "Цена", "Издательство");
        Console.WriteLine(new string('-', 80));

        foreach (var book in books)
        {
            Console.WriteLine("| {0,-5} | {1,-30} | {2,-15} | {3,-10:C2} | {4,-15} |",
                            book.BookId,
                            Truncate(book.Title, 30),
                            book.ISBN,
                            book.Price,
                            Truncate(book.Publisher ?? "-", 15));
        }
        Console.WriteLine(new string('-', 80));
    }

    private static string Truncate(string value, int maxLength)
    {
        return string.IsNullOrEmpty(value)
            ? value
            : value.Length <= maxLength
                ? value
                : value.Substring(0, maxLength - 3) + "...";
    }

    #endregion
}